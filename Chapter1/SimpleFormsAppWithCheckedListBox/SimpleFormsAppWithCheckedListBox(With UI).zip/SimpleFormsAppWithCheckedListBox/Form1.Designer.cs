﻿namespace SimpleFormsAppWithCheckedListBox
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            checkBox = new CheckedListBox();
            addButton = new Button();
            listBox = new ListBox();
            rmvButton = new Button();
            clearButton = new Button();
            selectButton = new Button();
            label1 = new Label();
            label2 = new Label();
            cancelButton = new Button();
            SuspendLayout();
            // 
            // checkBox
            // 
            checkBox.BackColor = Color.White;
            checkBox.Font = new Font("Arial", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            checkBox.ForeColor = Color.Black;
            checkBox.FormattingEnabled = true;
            checkBox.Location = new Point(195, 127);
            checkBox.Name = "checkBox";
            checkBox.Size = new Size(187, 204);
            checkBox.TabIndex = 0;
            // 
            // addButton
            // 
            addButton.BackColor = Color.FromArgb(217, 74, 32);
            addButton.FlatAppearance.BorderSize = 0;
            addButton.FlatStyle = FlatStyle.Flat;
            addButton.Font = new Font("Montserrat", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            addButton.ForeColor = Color.White;
            addButton.Location = new Point(238, 288);
            addButton.Name = "addButton";
            addButton.Size = new Size(105, 32);
            addButton.TabIndex = 1;
            addButton.Text = "ADD";
            addButton.UseVisualStyleBackColor = false;
            addButton.Click += addButton_Click;
            // 
            // listBox
            // 
            listBox.Font = new Font("Arial", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            listBox.FormattingEnabled = true;
            listBox.ItemHeight = 18;
            listBox.Location = new Point(388, 128);
            listBox.Name = "listBox";
            listBox.Size = new Size(187, 202);
            listBox.TabIndex = 2;
            // 
            // rmvButton
            // 
            rmvButton.BackColor = Color.FromArgb(51, 51, 51);
            rmvButton.FlatAppearance.BorderSize = 0;
            rmvButton.FlatStyle = FlatStyle.Flat;
            rmvButton.Font = new Font("Montserrat", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            rmvButton.ForeColor = Color.White;
            rmvButton.Location = new Point(388, 335);
            rmvButton.Name = "rmvButton";
            rmvButton.Size = new Size(187, 45);
            rmvButton.TabIndex = 3;
            rmvButton.Text = "REMOVE";
            rmvButton.UseVisualStyleBackColor = false;
            rmvButton.Click += rmvButton_Click;
            // 
            // clearButton
            // 
            clearButton.BackColor = Color.FromArgb(51, 51, 51);
            clearButton.FlatAppearance.BorderSize = 0;
            clearButton.FlatStyle = FlatStyle.Flat;
            clearButton.Font = new Font("Montserrat", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            clearButton.ForeColor = Color.White;
            clearButton.Location = new Point(388, 386);
            clearButton.Name = "clearButton";
            clearButton.Size = new Size(187, 45);
            clearButton.TabIndex = 4;
            clearButton.Text = "CLEAR ALL";
            clearButton.UseVisualStyleBackColor = false;
            clearButton.Click += clearButton_Click;
            // 
            // selectButton
            // 
            selectButton.BackColor = Color.FromArgb(51, 51, 51);
            selectButton.FlatAppearance.BorderSize = 0;
            selectButton.FlatStyle = FlatStyle.Flat;
            selectButton.Font = new Font("Montserrat", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            selectButton.ForeColor = Color.White;
            selectButton.Location = new Point(195, 336);
            selectButton.Name = "selectButton";
            selectButton.Size = new Size(187, 45);
            selectButton.TabIndex = 5;
            selectButton.Text = "SELECT ALL";
            selectButton.UseVisualStyleBackColor = false;
            selectButton.Click += selectButton_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Rounded MT Bold", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(296, 55);
            label1.Name = "label1";
            label1.Size = new Size(193, 28);
            label1.TabIndex = 6;
            label1.Text = "Simple Favorite";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial Rounded MT Bold", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Red;
            label2.Location = new Point(285, 80);
            label2.Name = "label2";
            label2.Size = new Size(215, 28);
            label2.TabIndex = 7;
            label2.Text = "Movie Picker App";
            // 
            // cancelButton
            // 
            cancelButton.BackColor = Color.FromArgb(51, 51, 51);
            cancelButton.FlatAppearance.BorderSize = 0;
            cancelButton.FlatStyle = FlatStyle.Flat;
            cancelButton.Font = new Font("Montserrat", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cancelButton.ForeColor = Color.White;
            cancelButton.Location = new Point(195, 387);
            cancelButton.Name = "cancelButton";
            cancelButton.Size = new Size(187, 45);
            cancelButton.TabIndex = 8;
            cancelButton.Text = "CANCEL";
            cancelButton.UseVisualStyleBackColor = false;
            cancelButton.Click += clrButton_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(800, 487);
            Controls.Add(cancelButton);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(selectButton);
            Controls.Add(clearButton);
            Controls.Add(rmvButton);
            Controls.Add(listBox);
            Controls.Add(addButton);
            Controls.Add(checkBox);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private CheckedListBox checkBox;
        private Button addButton;
        private ListBox listBox;
        private Button rmvButton;
        private Button clearButton;
        private Button selectButton;
        private Label label1;
        private Label label2;
        private Button clrButton;
        private Button cancelButton;
    }
}
