﻿namespace WinFormsApp2
{
    partial class FavoriteCartoonFormApp
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox = new PictureBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            comboBox1 = new ComboBox();
            viewButton = new Button();
            clearButton = new Button();
            label4 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox).BeginInit();
            SuspendLayout();
            // 
            // pictureBox
            // 
            pictureBox.BorderStyle = BorderStyle.FixedSingle;
            pictureBox.Location = new Point(402, 221);
            pictureBox.Name = "pictureBox";
            pictureBox.Size = new Size(281, 274);
            pictureBox.TabIndex = 0;
            pictureBox.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Montserrat SemiBold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(402, 193);
            label1.Name = "label1";
            label1.Size = new Size(65, 25);
            label1.TabIndex = 1;
            label1.Text = "Image";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Game Bubble", 26.2499962F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.FromArgb(34, 125, 182);
            label2.Location = new Point(289, 60);
            label2.Name = "label2";
            label2.Size = new Size(293, 37);
            label2.TabIndex = 2;
            label2.Text = "Simple Favorite";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.FromArgb(207, 232, 246);
            label3.Font = new Font("Game Bubble", 26.2499962F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.FromArgb(34, 125, 182);
            label3.Location = new Point(208, 97);
            label3.Name = "label3";
            label3.Size = new Size(475, 37);
            label3.TabIndex = 3;
            label3.Text = "Cartoon Character Picker";
            // 
            // comboBox1
            // 
            comboBox1.BackColor = Color.FromArgb(102, 153, 204);
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.FlatStyle = FlatStyle.Flat;
            comboBox1.Font = new Font("Montserrat SemiBold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            comboBox1.ForeColor = Color.White;
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(208, 221);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(188, 32);
            comboBox1.TabIndex = 4;
            // 
            // viewButton
            // 
            viewButton.BackColor = Color.FromArgb(65, 100, 223);
            viewButton.FlatAppearance.BorderSize = 0;
            viewButton.FlatStyle = FlatStyle.Flat;
            viewButton.Font = new Font("Montserrat", 8.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            viewButton.ForeColor = Color.White;
            viewButton.Location = new Point(208, 259);
            viewButton.Name = "viewButton";
            viewButton.Size = new Size(188, 42);
            viewButton.TabIndex = 5;
            viewButton.Text = "VIEW";
            viewButton.UseVisualStyleBackColor = false;
            viewButton.Click += viewButton_Click;
            // 
            // clearButton
            // 
            clearButton.BackColor = Color.FromArgb(65, 100, 223);
            clearButton.FlatAppearance.BorderSize = 0;
            clearButton.FlatStyle = FlatStyle.Flat;
            clearButton.Font = new Font("Montserrat", 8.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            clearButton.ForeColor = SystemColors.ButtonHighlight;
            clearButton.Location = new Point(208, 307);
            clearButton.Name = "clearButton";
            clearButton.Size = new Size(188, 42);
            clearButton.TabIndex = 6;
            clearButton.Text = "CLEAR";
            clearButton.UseVisualStyleBackColor = false;
            clearButton.Click += clearButton_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Montserrat SemiBold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(208, 193);
            label4.Name = "label4";
            label4.Size = new Size(135, 25);
            label4.TabIndex = 7;
            label4.Text = "Select an item:";
            // 
            // FavoriteCartoonFormApp
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(207, 232, 246);
            ClientSize = new Size(895, 595);
            Controls.Add(label4);
            Controls.Add(clearButton);
            Controls.Add(viewButton);
            Controls.Add(comboBox1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(pictureBox);
            Name = "FavoriteCartoonFormApp";
            Text = "Favorite Cartoon Form App";
            ((System.ComponentModel.ISupportInitialize)pictureBox).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox;
        private Label label1;
        private Label label2;
        private Label label3;
        private ComboBox comboBox1;
        private Button viewButton;
        private Button clearButton;
        private Label label4;
    }
}
