﻿namespace SimpleFormsApp
{
    partial class SimpleFormApp
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            firstName = new TextBox();
            middleName = new TextBox();
            lastName = new TextBox();
            suffixName = new TextBox();
            button1 = new Button();
            fnameValue = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(116, 86, 174);
            label1.Location = new Point(78, 64);
            label1.Name = "label1";
            label1.Size = new Size(255, 24);
            label1.TabIndex = 0;
            label1.Text = "Simple Form Application";
            // 
            // firstName
            // 
            firstName.Font = new Font("Arial", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            firstName.ForeColor = Color.Black;
            firstName.Location = new Point(78, 154);
            firstName.Multiline = true;
            firstName.Name = "firstName";
            firstName.Size = new Size(255, 26);
            firstName.TabIndex = 1;
            // 
            // middleName
            // 
            middleName.Font = new Font("Arial", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            middleName.ForeColor = Color.Black;
            middleName.Location = new Point(78, 226);
            middleName.Multiline = true;
            middleName.Name = "middleName";
            middleName.Size = new Size(255, 26);
            middleName.TabIndex = 2;
            // 
            // lastName
            // 
            lastName.Font = new Font("Arial", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lastName.ForeColor = Color.Black;
            lastName.Location = new Point(78, 304);
            lastName.Multiline = true;
            lastName.Name = "lastName";
            lastName.Size = new Size(255, 26);
            lastName.TabIndex = 3;
            // 
            // suffixName
            // 
            suffixName.Font = new Font("Arial", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            suffixName.ForeColor = Color.Black;
            suffixName.Location = new Point(78, 386);
            suffixName.Multiline = true;
            suffixName.Name = "suffixName";
            suffixName.Size = new Size(255, 26);
            suffixName.TabIndex = 4;
            suffixName.TextChanged += suffixName_TextChanged;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(116, 86, 174);
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Arial", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.White;
            button1.Location = new Point(128, 443);
            button1.Name = "button1";
            button1.Size = new Size(149, 41);
            button1.TabIndex = 5;
            button1.Text = "Submit";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // fnameValue
            // 
            fnameValue.AutoSize = true;
            fnameValue.Font = new Font("Arial", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            fnameValue.Location = new Point(78, 133);
            fnameValue.Name = "fnameValue";
            fnameValue.Size = new Size(84, 18);
            fnameValue.TabIndex = 6;
            fnameValue.Text = "First Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(78, 205);
            label2.Name = "label2";
            label2.Size = new Size(100, 18);
            label2.TabIndex = 7;
            label2.Text = "Middle Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(78, 283);
            label3.Name = "label3";
            label3.Size = new Size(82, 18);
            label3.TabIndex = 8;
            label3.Text = "Last Name";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(78, 365);
            label4.Name = "label4";
            label4.Size = new Size(49, 18);
            label4.TabIndex = 9;
            label4.Text = "Suffix";
            // 
            // SimpleFormApp
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(411, 550);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(fnameValue);
            Controls.Add(button1);
            Controls.Add(suffixName);
            Controls.Add(lastName);
            Controls.Add(middleName);
            Controls.Add(firstName);
            Controls.Add(label1);
            Name = "SimpleFormApp";
            Text = "FormApp";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox firstName;
        private TextBox middleName;
        private TextBox lastName;
        private TextBox suffixName;
        private Button button1;
        private Label fnameValue;
        private Label label2;
        private Label label3;
        private Label label4;
    }
}
