﻿namespace SimpleFormsAppWithMessageBoxes
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            firstName = new TextBox();
            lastName = new TextBox();
            middleName = new TextBox();
            suffixName = new TextBox();
            button1 = new Button();
            fnameValue = new Label();
            mnameValue = new Label();
            lnameValue = new Label();
            snameValue = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(0, 128, 255);
            label1.Location = new Point(73, 57);
            label1.Name = "label1";
            label1.Size = new Size(255, 24);
            label1.TabIndex = 0;
            label1.Text = "Simple Form Application";
            // 
            // firstName
            // 
            firstName.Font = new Font("Arial", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            firstName.Location = new Point(73, 154);
            firstName.Multiline = true;
            firstName.Name = "firstName";
            firstName.Size = new Size(255, 27);
            firstName.TabIndex = 1;
            // 
            // lastName
            // 
            lastName.Font = new Font("Arial", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lastName.Location = new Point(73, 319);
            lastName.Multiline = true;
            lastName.Name = "lastName";
            lastName.Size = new Size(255, 27);
            lastName.TabIndex = 2;
            // 
            // middleName
            // 
            middleName.Font = new Font("Arial", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            middleName.Location = new Point(73, 238);
            middleName.Multiline = true;
            middleName.Name = "middleName";
            middleName.Size = new Size(255, 27);
            middleName.TabIndex = 2;
            // 
            // suffixName
            // 
            suffixName.Font = new Font("Arial", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            suffixName.Location = new Point(73, 408);
            suffixName.Multiline = true;
            suffixName.Name = "suffixName";
            suffixName.Size = new Size(255, 27);
            suffixName.TabIndex = 3;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(0, 128, 255);
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Arial", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.White;
            button1.Location = new Point(131, 468);
            button1.Name = "button1";
            button1.Size = new Size(129, 43);
            button1.TabIndex = 4;
            button1.Text = "Submit";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // fnameValue
            // 
            fnameValue.AutoSize = true;
            fnameValue.Font = new Font("Arial", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            fnameValue.Location = new Point(73, 133);
            fnameValue.Name = "fnameValue";
            fnameValue.Size = new Size(84, 18);
            fnameValue.TabIndex = 5;
            fnameValue.Text = "First Name";
            // 
            // mnameValue
            // 
            mnameValue.AutoSize = true;
            mnameValue.Font = new Font("Arial", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            mnameValue.Location = new Point(73, 217);
            mnameValue.Name = "mnameValue";
            mnameValue.Size = new Size(100, 18);
            mnameValue.TabIndex = 6;
            mnameValue.Text = "Middle Name";
            // 
            // lnameValue
            // 
            lnameValue.AutoSize = true;
            lnameValue.Font = new Font("Arial", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lnameValue.Location = new Point(73, 298);
            lnameValue.Name = "lnameValue";
            lnameValue.Size = new Size(82, 18);
            lnameValue.TabIndex = 7;
            lnameValue.Text = "Last Name";
            // 
            // snameValue
            // 
            snameValue.AutoSize = true;
            snameValue.Font = new Font("Arial", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            snameValue.Location = new Point(73, 387);
            snameValue.Name = "snameValue";
            snameValue.Size = new Size(49, 18);
            snameValue.TabIndex = 8;
            snameValue.Text = "Suffix";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(413, 575);
            Controls.Add(snameValue);
            Controls.Add(lnameValue);
            Controls.Add(mnameValue);
            Controls.Add(fnameValue);
            Controls.Add(button1);
            Controls.Add(suffixName);
            Controls.Add(middleName);
            Controls.Add(lastName);
            Controls.Add(firstName);
            Controls.Add(label1);
            Name = "Form1";
            Text = "FormApp";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox firstName;
        private TextBox lastName;
        private TextBox middleName;
        private TextBox suffixName;
        private Button button1;
        private Label fnameValue;
        private Label mnameValue;
        private Label lnameValue;
        private Label snameValue;
    }
}
