﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            addBttn = new Button();
            rmvBttn = new Button();
            clrBttn = new Button();
            label1 = new Label();
            txtBox = new TextBox();
            lstBox = new ListBox();
            SuspendLayout();
            // 
            // addBttn
            // 
            addBttn.BackColor = Color.FromArgb(88, 171, 127);
            addBttn.FlatAppearance.BorderSize = 0;
            addBttn.FlatStyle = FlatStyle.Flat;
            addBttn.Font = new Font("Montserrat", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            addBttn.ForeColor = Color.White;
            addBttn.Location = new Point(139, 196);
            addBttn.Name = "addBttn";
            addBttn.Size = new Size(129, 39);
            addBttn.TabIndex = 1;
            addBttn.Text = "ADD";
            addBttn.UseVisualStyleBackColor = false;
            addBttn.Click += addBttn_Click;
            // 
            // rmvBttn
            // 
            rmvBttn.BackColor = Color.FromArgb(88, 171, 127);
            rmvBttn.FlatAppearance.BorderSize = 0;
            rmvBttn.FlatStyle = FlatStyle.Flat;
            rmvBttn.Font = new Font("Montserrat", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            rmvBttn.ForeColor = Color.White;
            rmvBttn.Location = new Point(466, 163);
            rmvBttn.Name = "rmvBttn";
            rmvBttn.Size = new Size(129, 39);
            rmvBttn.TabIndex = 2;
            rmvBttn.Text = "REMOVE";
            rmvBttn.UseVisualStyleBackColor = false;
            rmvBttn.Click += rmvBttn_Click;
            // 
            // clrBttn
            // 
            clrBttn.BackColor = Color.FromArgb(88, 171, 127);
            clrBttn.FlatAppearance.BorderSize = 0;
            clrBttn.FlatStyle = FlatStyle.Flat;
            clrBttn.Font = new Font("Montserrat", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            clrBttn.ForeColor = Color.White;
            clrBttn.Location = new Point(466, 208);
            clrBttn.Name = "clrBttn";
            clrBttn.Size = new Size(129, 39);
            clrBttn.TabIndex = 3;
            clrBttn.Text = "CLEAR ALL";
            clrBttn.UseVisualStyleBackColor = false;
            clrBttn.Click += clrBttn_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Rounded MT Bold", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(254, 89);
            label1.Name = "label1";
            label1.Size = new Size(238, 32);
            label1.TabIndex = 4;
            label1.Text = "Simple Form App";
            // 
            // txtBox
            // 
            txtBox.BackColor = SystemColors.MenuBar;
            txtBox.Font = new Font("Arial", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtBox.Location = new Point(139, 162);
            txtBox.Margin = new Padding(1, 5, 1, 5);
            txtBox.Multiline = true;
            txtBox.Name = "txtBox";
            txtBox.Size = new Size(129, 26);
            txtBox.TabIndex = 5;
            // 
            // lstBox
            // 
            lstBox.Font = new Font("Arial", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lstBox.FormattingEnabled = true;
            lstBox.ItemHeight = 18;
            lstBox.Location = new Point(274, 163);
            lstBox.Margin = new Padding(5, 3, 3, 5);
            lstBox.Name = "lstBox";
            lstBox.Size = new Size(186, 202);
            lstBox.TabIndex = 6;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(738, 465);
            Controls.Add(lstBox);
            Controls.Add(txtBox);
            Controls.Add(label1);
            Controls.Add(clrBttn);
            Controls.Add(rmvBttn);
            Controls.Add(addBttn);
            Name = "Form1";
            Text = "FormApp";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button addBttn;
        private Button rmvBttn;
        private Button clrBttn;
        private Label label1;
        private TextBox txtBox;
        private ListBox lstBox;
    }
}
